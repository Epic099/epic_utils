# epic_utils
Latest Version: 0.4.5

## Description
A simple package that I am creating overtime. It includes tools for pygame, mathematics, roblox or debuging. The package is being upgraded over time.

## Installation
### Pip
```bash
pip install epic_utils
```

