from argon2 import PasswordHasher as _PasswordHasher
from argon2.exceptions import VerifyMismatchError
import secrets

class PasswordManager:
    _hasher = _PasswordHasher()
    @staticmethod
    def hash(password: str):
        hash = PasswordManager._hasher.hash(password)
        return hash

    @staticmethod
    def check_password(hash: str, password: str):
        try:
            PasswordManager._hasher.verify(hash, password)
        except VerifyMismatchError:
            return False    
        except Exception:
            return False
        return True
    
    @staticmethod
    def create_key():
        return secrets.token_hex(32)
