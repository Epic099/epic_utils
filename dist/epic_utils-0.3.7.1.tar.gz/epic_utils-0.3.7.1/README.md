# epic_utils
Latest Version: 0.3.7

## Description
A simple package that I am creatng overtime. It includes tools fIor pygame, mathematics, roblox or debuging. The package is being upgraded over time.

## Installation
### Pip
```bash
pip install epic_utils
```

