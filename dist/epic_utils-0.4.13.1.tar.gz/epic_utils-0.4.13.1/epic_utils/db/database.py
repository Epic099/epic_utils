import struct
from .datatype import DB_Str, DB_Array, DB_Value, DB_UInt
from datetime import datetime
from enum import Enum

MAGICNUMBER = "EPDB".encode("utf-8")
HEADER_IDENT = "HEAD".encode("utf-8")
DATA_IDENT = "DATA".encode("utf-8")
END_IDENT = "STOP".encode("utf-8")
DATEFORMAT = "%d%m%Y%H%M"
FORMAT_VERSION = 3 #Version 1 is simple format with only basic data types. Version 2 allows for more complex data types like arrays. Version 3 introduced table ids to better identify tables

class FilterType(Enum):	
    NONE = 0
    EQUALS = 1
    GREATER = 2
    GREATER_EQUAL = 3
    LESS = 4
    LESS_EQUAL = 5
    CONTAINS = 6
    CONTAINS_LOWER = 7 # ignores capitalization
    AND = 8
    OR = 9
		
class DB_Object:
	def __init__(self):
		pass
		
	def get_values(self):
		"""
			return: Array -> [attribute_name, attribute_type, attribute_value]
		"""
		result = []
		children = vars(self)
		keys = list(children.keys())
		keys.sort()
		for name in keys:
			value = getattr(self, name)
			typ = type(value)
			try:
				_ = getattr(typ, "DB_IDENT")
				result.append([name, typ, value.get()])
			except AttributeError:
				pass
				#Not a valid value to store
		return result

class DB_FilterRule():
	def __init__(self, value_name: str, compare_value, compare_rule: FilterType):
		if compare_rule not in [FilterType.LESS, FilterType.LESS_EQUAL, FilterType.EQUALS, FilterType.GREATER, FilterType.GREATER_EQUAL, FilterType.CONTAINS, FilterType.CONTAINS_LOWER]:
			raise Exception("Invalid filter compare type")
		self.value_name = value_name
		self.compare_value = compare_value
		self.type = compare_rule
		if (self.type == FilterType.CONTAINS or self.type == FilterType.CONTAINS_LOWER) and not isinstance(self.compare_value, str):
			raise Exception("compare value must be a string")
		if self.type == FilterType.CONTAINS_LOWER:
			self.compare_value = self.compare_value.lower()
        
	def compare(self, value):
		if self.type == FilterType.EQUALS:
			return value == self.compare_value
		elif self.type == FilterType.GREATER:
			return value > self.compare_value
		elif self.type == FilterType.GREATER_EQUAL:
			return value >= self.compare_value
		elif self.type == FilterType.LESS:
			return value < self.compare_value
		elif self.type == FilterType.LESS_EQUAL:
			return value <= self.compare_value
		elif self.type == FilterType.CONTAINS and isinstance(value, str):
			return True if str.find(value, self.compare_value) >= 0 else False
		elif self.type == FilterType.CONTAINS_LOWER and isinstance(value, str):
			return True if str.find(value.lower(), self.compare_value) >= 0 else False
		return False

class DB_Table:
	def __init__(self, index: int, id: str, key_name: str, obj):
		self.index = index
		self.id = id
		self.key_name = key_name
		self.obj = obj
		_obj = obj()
		
		self.key_type = type(getattr(_obj, self.key_name))
		_values = _obj.get_values()
		self.value_names = [temp[0] for temp in _values]
		self.columns = [[temp[0], temp[1].DB_IDENT] for temp in _values] # [name, type]
		
		self.values = {}
		
	def insert(self, obj):
		if not isinstance(obj, self.obj):
			raise TypeError(f"Invalid type. Expected <{self.obj.__name__}> got <{type(obj).__name__}>")
			#return # can only store provided objs
		key = getattr(obj, self.key_name)
		if key.get() in self.values.keys():
			raise IndexError(f"Key already exists in table")
		self.values[key.get()] = obj

	def update(self, obj):
		if not isinstance(obj, self.obj):
			raise TypeError(f"Invalid type. Expected <{self.obj.__name__}> got <{type(obj).__name__}>")
			#return # can only store provided objs
		key = getattr(obj, self.key_name)
		self.values[key.get()] = obj

	def get(self, key):
		if getattr(type(key), "FORMAT", -1) == -1 or type(key).DB_IDENT != self.key_type.DB_IDENT:
			raise IndexError("Invalid key")
		if key.get() not in self.values.keys():
			return None
		return self.values[key.get()]

	def get_all(self):
		return list(self.values.items())

	def filter(self, filters: list[DB_FilterRule], filter_combine: FilterType = FilterType.OR):
		if filter_combine not in [FilterType.OR, FilterType.AND]:
			raise Exception("Invalid filter combine type")
		#validating filters
		for filter in filters:
			if filter.value_name not in self.value_names:
				raise Exception("invalid filters")
		result = []
		for key, value in self.values.items():
			filter_result = [filter.compare(getattr(value, filter.value_name).get()) for filter in filters]
			if filter_combine == FilterType.AND and all(filter_result):
				result.append(value)
				continue
			if filter_combine == FilterType.OR and any(filter_result):
				result.append(value)
				continue
		return result

class DB_RAWTable:
	def __init__(self, index: int, id: str, key_name: str, key_type: DB_Value, columns):
		self.index = index
		self.id = id
		self.key_name = key_name
		self.key_type = key_type
		self.columns = [[temp[0], temp[1].DB_IDENT] for temp in columns]
		self.values = {}
        
	def insert(self, value):
		if not isinstance(value, dict):
			raise ValueError("Invalid value type")
		if not self.key_name in value.keys():
			raise ValueError("Invalid key")
		key = value[self.key_name]
		if key.get() in self.values.keys():
			raise IndexError(f"Key already exists in table")
		self.values[key.get()] = value

	def update(self, value):
		if not isinstance(value, dict):
			raise ValueError("Invalid value type")
		if not self.key_name in value.keys():
			raise ValueError("Invalid key")
		key = value[self.key_name]
		self.values[key.get()] = value
            
	def get(self, key: DB_Value):
		if getattr(type(key), "FORMAT", -1) == -1 or type(key).DB_IDENT != self.key_type.DB_IDENT:
			raise IndexError("Invalid key")
		if key.get() not in self.values.keys():
			return None
		return self.values[key.get()]
        
	def get_all(self):
		return list(self.values.items())

	def filter(self, filters: list[DB_FilterRule], filter_combine: FilterType = FilterType.OR):
		if filter_combine not in [FilterType.OR, FilterType.AND]:
			raise Exception("Invalid filter combine type")
		#validating filters
		for filter in filters:
			if filter.value_name not in self.value_names:
				raise Exception("invalid filters")
		result = []
		for key, value in self.values.items():
			filter_result = [filter.compare(value[filter.value_name].get()) for filter in filters]
			if filter_combine == FilterType.AND and all(filter_result):
				result.append(value)
				continue
			if filter_combine == FilterType.OR and any(filter_result):
				result.append(value)
				continue
		return result
		
class Database():
	def __init__(self, filename, FORMAT = FORMAT_VERSION):
		if(FORMAT < 1 or FORMAT > FORMAT_VERSION or not isinstance(FORMAT, int)):
			raise ValueError("Invalid Database format")
		self.format = FORMAT
		self.tables: list[DB_Table] = []
		self.raw_tables: list[DB_RAWTable] = []
		self.filename = filename

	def get_table(self, index_or_id: int|str, raw=False) -> DB_Table|DB_RAWTable:
		if raw == False:
			for table in self.tables:
				if table.index == index_or_id or table.id == index_or_id:
					return table
		else:
			for table in self.raw_tables:
				if table.index == index_or_id or table.id == index_or_id:
					return table
 
	def get_all_tables(self, raw=False) -> list[DB_Table]|list[DB_RAWTable]:
		if raw == False:
			return self.tables
		else:
			return self.raw_tables

	def get_all_table_ids(self, raw=False) -> list[str]:
		result = [table.id for table in self.tables] if raw == False else [table.id for table in self.raw_tables]
		return result
	
	def insert(self, table_index, obj, raw=False):
		table = self.get_table(table_index, raw=raw)
		if table == None:
			raise IndexError("Table index doesnt exist")
		table.insert(obj)

	def update(self, table_index, obj, raw=False):
		table = self.get_table(table_index, raw=raw)
		if table == None:
			raise IndexError("Table index doesnt exist")
		table.update(obj)

	def get(self, table_index: int, key: DB_Value, raw=False):
		table = self.get_table(table_index, raw=raw)
		if table == None:
			raise Exception("Table index does not exist")
		return table.get(key)

	def get_all(self, table_index: int, raw=False):
		table = self.get_table(table_index, raw=raw)
		if table == None:
			raise Exception("Table index does not exist")
		return table.get_all()

	def filter(self, table_index: int, filters: list[DB_FilterRule], filter_combine: FilterType = FilterType.OR, raw=False):
		table = self.get_table(table_index, raw=raw)
		if table == None:
			raise Exception("Table index does not exist")
		return table.filter(filters, filter_combine=filter_combine)

	def register_table(self, index: int, id: str, key_name: str, obj: any):
		for table in self.tables:
			if table.index == index or table.id == id:
				raise IndexError("Table indices and identifiers must be unique")
		self.tables.append(DB_Table(index, id, key_name, obj))

	def _register_rawtable(self, index: int, id: str, key_name: str, key_type: DB_Value, columns):
		for table in self.raw_tables:
			if table.index == index or table.id == id:
				raise IndexError("Table indices and identifiers must be unique")
		self.raw_tables.append(DB_RAWTable(index, id, key_name, key_type, columns))
	
	def save(self):
		#struct types (for myself because i cant f*cking remember, B = 1Byte, H = 2Bytes. I=4Bytes)
		with open(self.filename, "wb") as file:
			file.write(MAGICNUMBER) # identify file type
			file.write(struct.pack(">B", 0)) #Space
			file.write(HEADER_IDENT) # header
			file.write(struct.pack(">B", FORMAT_VERSION)) #format version
			self.format =  FORMAT_VERSION
			file.write(struct.pack(">I", len(self.tables))) #table count
			file.write(datetime.now().strftime(DATEFORMAT).encode("utf-8")) # save time
			
			file.write(DATA_IDENT) # data
			
			for table in self.tables:
				file.write(struct.pack(">I", table.index)) # table index -> later used to identify tables
				file.write(struct.pack(">I", len(table.id)))
				file.write(table.id.encode("utf-8"))
				file.write(struct.pack(">B", table.key_type.DB_IDENT)) #key type
				file.write(struct.pack(">H", len(table.key_name))) # key length (maybe change to 1 Byte length?)
				file.write(table.key_name.encode("utf-8")) # key name
				file.write(struct.pack(">B", len(table.columns))) # number of attributes				
				file.write(struct.pack(">I", len(table.values.keys()))) # number of entries
				for col in table.columns:
					file.write(struct.pack(">B", col[1])) # attribute type
					file.write(struct.pack(">H", len(col[0]))) # name length of attribute (maybe also change to 1 Byte?)
					file.write(col[0].encode("utf-8")) # attribute name
				for key in table.values.keys():
					if table.key_type.DB_IDENT == DB_Str.DB_IDENT:
						file.write(struct.pack(">I", len(key)))
						file.write(key.encode("utf-8"))
					else:
						file.write(table.key_type(value=key).getBytes()) # key (only int/float allowed for now as I need to implement keys with variable length)
					obj = table.values[key]
					for col in table.columns:
						if col[1] == DB_Str.DB_IDENT:
							file.write(struct.pack(">I", getattr(obj, col[0]).getAllocation()[0])) # value length
							file.write(getattr(obj, col[0]).getBytes())
						elif col[1] == DB_Array.DB_IDENT:
							arr = getattr(obj, col[0])
							file.write(struct.pack(">I", arr.length)) # Length of Array
							file.write(struct.pack(">B", arr.typ.DB_IDENT))
							if arr.typ.DB_IDENT == DB_Str.DB_IDENT:
								for i in range(0, arr.length):
									file.write(struct.pack(">I", arr[i].getAllocation()[0]))
									file.write(arr[i].getBytes())
							else:
								for i in range(0, arr.length):
									file.write(arr[i].getBytes())
						else:
							file.write(getattr(obj, col[0]).getBytes()) # value of each coloumn (also no variable length now)
			file.write(END_IDENT)
			
	def saveRAW(self):
		#struct types (for myself because i cant f*cking remember, B = 1Byte, H = 2Bytes. I=4Bytes)
		with open(self.filename, "wb") as file:
			file.write(MAGICNUMBER) # identify file type
			file.write(struct.pack(">B", 0)) #Space
			file.write(HEADER_IDENT) # header
			file.write(struct.pack(">B", FORMAT_VERSION)) #format version (current v = 2)	
			self.format =  FORMAT_VERSION
			file.write(struct.pack(">I", len(self.raw_tables))) #table count
			file.write(datetime.now().strftime(DATEFORMAT).encode("utf-8")) # save time
			
			file.write(DATA_IDENT) # data
			
			for table in self.raw_tables:
				file.write(struct.pack(">I", table.index)) # table index -> later used to identify tables
				file.write(struct.pack(">I", len(table.id))) # table id/name
				file.write(table.id.encode("utf-8"))
				file.write(struct.pack(">B", table.key_type.DB_IDENT)) #key type
				file.write(struct.pack(">H", len(table.key_name))) # key length (maybe change to 1 Byte length?)
				file.write(table.key_name.encode("utf-8")) # key name
				file.write(struct.pack(">B", len(table.columns))) # number of attributes				
				file.write(struct.pack(">I", len(table.values.keys()))) # number of entries
				for col in table.columns:
					file.write(struct.pack(">B", col[1])) # attribute type
					file.write(struct.pack(">H", len(col[0]))) # name length of attribute (maybe also change to 1 Byte?)
					file.write(col[0].encode("utf-8")) # attribute name
				for key in table.values.keys():
					if table.key_type.DB_IDENT == DB_Str.DB_IDENT:
						file.write(struct.pack(">I", len(key)))
						file.write(key.encode("utf-8"))
					else:
						file.write(table.key_type(value=key).getBytes()) # key (only int/float allowed for now as I need to implement keys with variable length)
					obj = table.values[key]
					for col in table.columns:
						if col[1] == DB_Str.DB_IDENT:
							file.write(struct.pack(">I", obj[col[0]].getAllocation()[0])) # value length
							file.write(obj[col[0]].getBytes())
						elif col[1] == DB_Array.DB_IDENT:
							arr = obj[col[0]]
							file.write(struct.pack(">I", arr.length)) # Length of Array
							file.write(struct.pack(">B", arr.typ.DB_IDENT))
							if arr.typ.DB_IDENT == DB_Str.DB_IDENT:
								for i in range(0, arr.length):
									file.write(struct.pack(">I", arr[i].getAllocation()[0]))
									file.write(arr[i].getBytes())
							else:
								for i in range(0, arr.length):
									file.write(arr[i].getBytes())
						else:
							file.write(obj[col[0]].getBytes()) # value of each coloumn (also no variable length now)
   
	def read(self):
		for table in self.tables:
			table.values = {}
		try:
			with open(self.filename, "rb") as file:
				magic = file.read(len(MAGICNUMBER))
				if magic != MAGICNUMBER:
					raise Exception("Wrong file type")
				file.read(1) # space
				head_ident = file.read(len(HEADER_IDENT))
				if head_ident != HEADER_IDENT:
					raise Exception("Corrupted File header")
				version = struct.unpack(">B", file.read(1))[0]
				if version == 3:
					table_count = struct.unpack(">I", file.read(4))[0]
					if table_count != len(self.tables): # maybe remove later so more tables can be added after a file has been created
						raise Exception(f"Tables not correctly initialized. Expected {table_count} table{'s' if table_count > 1 else ''} got {len(self.tables)}")
					date = datetime.strptime(file.read(12).decode("utf-8"), DATEFORMAT)
					data_ident = file.read(len(DATA_IDENT))
					if data_ident != DATA_IDENT:
						raise Exception("Corrupted File data")
					for i in range(0, table_count, 1):
						table_index = struct.unpack(">I", file.read(4))[0]
						table_id_len = struct.unpack(">I", file.read(4))[0]
						table_id = file.read(table_id_len).decode("utf-8")
						table = self.get_table(table_index)
						key_ident = struct.unpack(">B", file.read(1))[0]
						key_type = DB_Value.getType(key_ident)
						key_length = struct.unpack(">H", file.read(2))[0]
						key_name = file.read(key_length).decode("utf-8")
						if table.key_name != key_name:
							raise Exception("Format Error. Table has wrong key name")

						attribute_count = struct.unpack(">B", file.read(1))[0]
						entry_count = struct.unpack(">I", file.read(4))[0]
						columns = []
						for i in range(0, attribute_count, 1):
							typ = DB_Value.getType(struct.unpack(">B", file.read(1))[0])
							name_length = struct.unpack(">H", file.read(2))[0]
							attribute_name = file.read(name_length).decode("utf-8")
							columns.append([attribute_name, typ])
						
						for i in range(0, entry_count, 1):
							key = None
							if key_ident == DB_Str.DB_IDENT:
								key = file.read(struct.unpack(">I", file.read(4))[0]).decode("utf-8")
							else:
								key = struct.unpack(key_type.FORMAT, file.read(key_type().getAllocation()[0]))[0]
							values = {}
							for k in range(0, attribute_count):
								value = None
								if columns[k][1].DB_IDENT == DB_Str.DB_IDENT:
									length = struct.unpack(">I", file.read(4))[0]
									value = file.read(length).decode("utf-8")
									values[columns[k][0]] = value
									continue
								elif columns[k][1].DB_IDENT == DB_Array.DB_IDENT:
									array_length = struct.unpack(">I", file.read(4))[0]
									array_type = DB_Value.getType(struct.unpack(">B", file.read(1))[0])
									array_values = []
									if array_type.DB_IDENT == DB_Str.DB_IDENT:
										for i in range(0, array_length):
											string_length = struct.unpack(">I", file.read(4))[0]
											array_values.append(DB_Str(file.read(string_length).decode("utf-8")))
									else:
										for i in range(0, array_length):
											array_values.append(array_type(struct.unpack(array_type.FORMAT, file.read(array_type().getAllocation()[0]))[0]))
									values[columns[k][0]] = array_values
									continue
								value = struct.unpack(columns[k][1].FORMAT, file.read(columns[k][1]().getAllocation()[0]))[0]
								values[columns[k][0]] = value
							self.insert(table_index, table.obj(**values))
				else:
					raise Exception("Unsupported file fomat")
		except FileNotFoundError:
			self.save()
   
	def readRAW(self):
		self.raw_tables = []
		try:
			with open(self.filename, "rb") as file:
				magic = file.read(len(MAGICNUMBER))
				if magic != MAGICNUMBER:
					raise Exception("Wrong file type")
				file.read(1) # space
				head_ident = file.read(len(HEADER_IDENT))
				if head_ident != HEADER_IDENT:
					raise Exception("Corrupted File header")
				version = struct.unpack(">B", file.read(1))[0]
				if version == 3:
					table_count = struct.unpack(">I", file.read(4))[0]
					date = datetime.strptime(file.read(12).decode("utf-8"), DATEFORMAT)
					data_ident = file.read(len(DATA_IDENT))
					if data_ident != DATA_IDENT:
						raise Exception("Corrupted File data")
					for i in range(0, table_count, 1):
						table_index = struct.unpack(">I", file.read(4))[0]
						table_id_len = struct.unpack(">I", file.read(4))[0]
						table_id = file.read(table_id_len).decode("utf-8")
						key_ident = struct.unpack(">B", file.read(1))[0]
						key_type = DB_Value.getType(key_ident)
						key_length = struct.unpack(">H", file.read(2))[0]
						key_name = file.read(key_length).decode("utf-8")


						attribute_count = struct.unpack(">B", file.read(1))[0]
						entry_count = struct.unpack(">I", file.read(4))[0]
						columns = []
						for i in range(0, attribute_count, 1):
							typ = DB_Value.getType(struct.unpack(">B", file.read(1))[0])
							name_length = struct.unpack(">H", file.read(2))[0]
							attribute_name = file.read(name_length).decode("utf-8")
							columns.append([attribute_name, typ])
						self._register_rawtable(table_index, table_id, key_name, key_type, columns)
						for i in range(0, entry_count, 1):
								key = None
								if key_ident == DB_Str.DB_IDENT:
									key = file.read(struct.unpack(">I", file.read(4))[0]).decode("utf-8")
								else:
									key = struct.unpack(key_type.FORMAT, file.read(key_type().getAllocation()[0]))[0]
								values = {}
								for k in range(0, attribute_count):
									value = None
									if columns[k][1].DB_IDENT == DB_Str.DB_IDENT:
										length = struct.unpack(">I", file.read(4))[0]
										value = file.read(length).decode("utf-8")
										values[columns[k][0]] = DB_Str(value=value)
										continue
									elif columns[k][1].DB_IDENT == DB_Array.DB_IDENT:
										array_length = struct.unpack(">I", file.read(4))[0]
										array_type = DB_Value.getType(struct.unpack(">B", file.read(1))[0])
										array_values = []
										if array_type.DB_IDENT == DB_Str.DB_IDENT:
											for i in range(0, array_length):
												string_length = struct.unpack(">I", file.read(4))[0]
												array_values.append(DB_Str(file.read(string_length).decode("utf-8")))
										else:
											for i in range(0, array_length):
												array_values.append(array_type(struct.unpack(array_type.FORMAT, file.read(array_type().getAllocation()[0]))[0]))
										values[columns[k][0]] = DB_Array(array_type, values=array_values)
										continue
									value = struct.unpack(columns[k][1].FORMAT, file.read(columns[k][1]().getAllocation()[0]))[0]
									values[columns[k][0]] = columns[k][1](value)
								self.insert(table_index, values, raw=True)
		except FileNotFoundError:
			print("Cannot initialize file in raw mode")
    
       
    
	
    